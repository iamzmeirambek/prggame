#include "Application.h"
#include <iostream>

using namespace std;


// fight function
void Application::fight(Character &character) {
    cout << "Welcome to battle!\n";

    cout << "Please choose a opponent\n";

    for(int i = 0; i < opponents.size(); i++){
        opponents[i].getCharacterInfo(i);
    }

    cout << "Input id of enemy:\n";

    int id;
    cin >> id;

    Character enemy = opponents[id];
    cout << "Today's battle: \n";

    cout << character.name << " VS " << enemy.name << "\n";

    cout << "Fight log:\n";

    while(true){
        cout << "Your hit!\n";
        enemy.HP -= character.Atk;
        cout << "Enemy hp: " << max(0, enemy.HP) << "\n";

        if(enemy.HP <= 0){
            cout << "-------------------\n\nYou win!\n";
            cout << "You gain: 50 exp, " << enemy.gold << " gold.\n";
            character.exp += 50;
            character.checkLvl();

            if(!enemy.inventory.empty()){
                cout << "\n";
                for(int i = 0; i < enemy.inventory.size(); i++){
                    cout << "#" << i << ": " << enemy.inventory[i].name << "\n";
                }

                cout << "Want to add items to your inventory ? Type id or -1\n";
                int num;
                cin >> num;
                if(num == -1){
                    break;
                } else {
                    if(character.inventory.size() >= 3){
                        cout << "Sorry, your inventory is full already\n";
                        break;
                    } else {
                        character.inventory.push_back(enemy.inventory[num]);
                    }
                }

            }

            break;
        }

        cout << "Enemy's hit!\n";
        character.HP -= enemy.Atk;
        cout << "Your hp: " << max(0, character.HP) << "\n";

        if(character.HP <= 0){
            cout << "You lose :(\n Game over\n";
            exit(0);
            break;
        }

    }
}

// sleep function

void Application::sleep(Character &character) {
    cout << "Now, I am full of energy, boss!\n";
    cout << "HP restored to " << character.maxHP << "\n";
    character.HP = character.maxHP;
}

// show inventory function

void Application::showInventory(Character &character) {
    vector <Item> &inventory = character.inventory;
    for(auto item : inventory){
        cout << item.name << " ";
    }
    cout << "Total " << inventory.size() << " items in the inventory\n";
    cout << "---\n\n";
}

// start of our programm

void Application::start() {
    cout << "Hello, Welcome to our rpg game\n";
    cout << "First of all, let's create a new character\n";

    cout << "Enter a name: ";
    string name;
    cin >> name;
    cout << "\n Enter a HP: ";
    int hp;
    cin >> hp;
    cout << "\n Enter a attack per hit\n";
    int atk;
    cin >> atk;

    Character character(name, hp, atk);

    cout << "\n";

    while(true){
        cout << "1: Fight\n";
        cout << "2: Inventory\n";
        cout << "3: My character\n";
        cout << "4: Sleep\n";
        cout << "0: Exit";

        int choice;
        cin >> choice;

        if(choice == 1){
            fight(character);
        } else if(choice == 2){
            showInventory(character);
        } else if(choice == 3){
            character.getCharacterInfo(1);
        } else if(choice == 4){
            sleep(character);
        } else {
            exit(0);
        }
    }
}


// this is a constructor, at the beginning we fill our array with some data.
Application::Application() {
    opponents.push_back(*new Character("Azamat", 89, 23));
    opponents.push_back(*new Character("Nursultan", 59, 103));
    opponents.push_back(*new Character("Adilet", 189, 5));
    opponents.push_back(*new Character("Ilyas", 50, 50));
    opponents.push_back(*new Character("Amanzhol", 999999, 999999));
    opponents.push_back(*new Character("Manat", 89, 33));
    opponents.push_back(*new Character("Abdu", 19, 303));

    opponents[0].addItemToInventory(*new Item("AK-47"));
    opponents[1].addItemToInventory(*new Item("Deagle"));
    opponents[2].addItemToInventory(*new Item("Famas"));
    opponents[3].addItemToInventory(*new Item("AWP"));
    opponents[6].addItemToInventory(*new Item("Scout"));
    opponents[5].addItemToInventory(*new Item("Dual Berretes"));
    opponents[4].addItemToInventory(*new Item("M4A4"));
}
