#include <iostream>
#include <thread>

#include "Application.h"

// function to printing some random quotes from array using parallel thread
void GenerateQuotes(){
    string quotes[5] = { "\nThis Is My Story Not Yours.\n",
                         "\nShut Your Trap And Fight!\n",
                         "\nKings Die, Realms Fall, But Magic Endures\n",
                         "\nDon't Blame Yourself\n",
                         "\nYou were always an unruly child.\n"
    };

    srand(NULL);

    for(int i = 0; i<=25; i++){
        this_thread::sleep_for(chrono::milliseconds(rand()%20000+10000));
        cout<<quotes[rand()%4]<<"\n";

    }
}

int main() {

    thread thr (GenerateQuotes);
    thr.detach();
    Application application;


    // start application
    application.start();
}
