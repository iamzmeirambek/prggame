#include "Character.h"
#include <iostream>

using namespace std;


// just output data of our character
void Character::getCharacterInfo(int num) {
    cout << "\n\n-";
    cout << "#" << num << ": " << name << "\n";
    cout << "HP: " << HP << "/" << maxHP << "\n";
    cout << "Gold: " << gold << "\n";
    cout << "Level: " << level << "\n";
    cout << "-\n\n";
}

// constructor
Character::Character(const string &name, int hp, int atk) : name(name), HP(hp), Atk(atk) {
    this->maxHP = hp;
    this->level = 0;
    this->exp = 0;
    this->gold = 0;
}

// add item to our inventory
void Character::addItemToInventory(Item item) {
    inventory.push_back(item);
}

// if our exp is more than one hundred, we need to level up

void Character::checkLvl() {
    if(exp > 100){
        exp -= 100;
        cout << "\n Level up!!! \n";
        level++;
    }
}

