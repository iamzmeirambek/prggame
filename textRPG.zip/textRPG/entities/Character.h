#ifndef TEXTRPG_CHARACTER_H
#define TEXTRPG_CHARACTER_H

#include <string>
#include <vector>
#include "Item.h"

using namespace std;

class Character {
public:
    string name;
    int HP;
    int maxHP;
    int Atk;
    int exp;
    int level;
    int gold;

    vector<Item> inventory;
    Character(const string &name, int hp, int atk);

    void checkLvl();
    void addItemToInventory(Item item);
    void getCharacterInfo(int num);
};


#endif //TEXTRPG_CHARACTER_H
