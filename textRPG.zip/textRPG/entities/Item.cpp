//
// Created by undefined on 21.09.2021.
//

#include "Item.h"

Item::Item(const string &name) : name(name) {}
