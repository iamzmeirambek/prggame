//
// Created by undefined on 21.09.2021.
//

#include <string>

using namespace std;

#ifndef TEXTRPG_ITEM_H
#define TEXTRPG_ITEM_H


class Item {
public:
    string name;
    Item(const string &name);
};


#endif //TEXTRPG_ITEM_H
