#ifndef TEXTRPG_APPLICATION_H
#define TEXTRPG_APPLICATION_H

#include "entities/Character.h"

class Application {
public:

    Application();

    vector<Character>opponents;

    void showInventory(Character &character);
    void start();
    void fight(Character &character);

    void sleep(Character &character);
};


#endif //TEXTRPG_APPLICATION_H
